
//
// This file is auto-generated. Please don't modify it!
//
package org.opencv.phase_unwrapping;



// C++: class Phase_unwrapping
//javadoc: Phase_unwrapping

public class Phase_unwrapping {



}
