
//
// This file is auto-generated. Please don't modify it!
//
package org.opencv.structured_light;



// C++: class Structured_light
//javadoc: Structured_light

public class Structured_light {

    public static final int
            FTP = 0,
            PSP = 1,
            FAPS = 2,
            DECODE_3D_UNDERWORLD = 0;




}
