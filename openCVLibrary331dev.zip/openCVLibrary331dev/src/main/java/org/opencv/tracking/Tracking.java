
//
// This file is auto-generated. Please don't modify it!
//
package org.opencv.tracking;



// C++: class Tracking
//javadoc: Tracking

public class Tracking {



}
