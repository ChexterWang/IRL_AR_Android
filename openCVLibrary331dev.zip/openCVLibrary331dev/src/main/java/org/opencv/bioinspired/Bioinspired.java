
//
// This file is auto-generated. Please don't modify it!
//
package org.opencv.bioinspired;



// C++: class Bioinspired
//javadoc: Bioinspired

public class Bioinspired {

    public static final int
            RETINA_COLOR_RANDOM = 0,
            RETINA_COLOR_DIAGONAL = 1,
            RETINA_COLOR_BAYER = 2;




}
